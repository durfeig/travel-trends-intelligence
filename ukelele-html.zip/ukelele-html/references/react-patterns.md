# React / Artifact — Patrones JSX + Tailwind

Para artifacts en Claude.ai. Usa Tailwind con clases custom mapeadas a la paleta Ukelele. Componentes funcionales con hooks, sin librerías externas más allá de las disponibles por default en artifacts (lucide-react, recharts).

> **Importante**: en artifacts de Claude.ai NO está disponible Tailwind config personalizado — solo las utilidades core. Por eso esta guía usa clases arbitrarias `[#hex]` y combinaciones de utilidades estándar para reproducir el sistema. La paleta se aplica vía clases arbitrarias (ej: `bg-[#E30233]`) y los componentes se construyen manualmente.

## Tabla de contenidos
1. [Setup base de un artifact Ukelele](#1-setup-base)
2. [Logo en artifacts](#2-logo-en-artifacts)
3. [Constantes de paleta y tipografía](#3-constantes-de-paleta-y-tipografía)
4. [Componente Hero](#4-componente-hero)
5. [Separador de sección](#5-separador-de-sección)
6. [Big Stat](#6-big-stat)
7. [Highlights / Métricas](#7-highlights--métricas)
8. [Cards / Grid](#8-cards--grid)
9. [Comparación dos columnas](#9-comparación-dos-columnas)
10. [Iniciativas numeradas](#10-iniciativas-numeradas)
11. [Tabla de datos](#11-tabla-de-datos)
12. [CTA Block](#12-cta-block)
13. [Footer](#13-footer)
14. [Componente App de ejemplo](#14-app-de-ejemplo)

---

## 1. Setup base

Estructura típica de un artifact React Ukelele:

```jsx
import React, { useState } from "react";
import { TrendingUp, Target, Users, BarChart3 } from "lucide-react";

// Las fuentes hay que cargarlas en runtime — no hay <link> en artifact
// Lo hacemos vía useEffect inyectando un <link> al <head>
import { useEffect } from "react";

function useUkeleleFonts() {
  useEffect(() => {
    const id = "uke-fonts-link";
    if (document.getElementById(id)) return;
    const link = document.createElement("link");
    link.id = id;
    link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&family=Lato:wght@400;700;900&display=swap";
    document.head.appendChild(link);
  }, []);
}

export default function App() {
  useUkeleleFonts();

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: "'Lato', sans-serif" }}>
      {/* Secciones acá */}
    </div>
  );
}
```

---

## 2. Logo en artifacts

En artifacts de Claude.ai no hay filesystem — no podemos importar `logo-ukelele-color.png` directamente. Tres opciones:

### Opción A (recomendada): logo embebido como base64 inline
Antes de generar el artifact, leer el PNG, convertir a base64 y pegarlo como string constante.

```python
# Antes de escribir el artifact:
import base64
with open('/mnt/skills/user/ukelele-html/assets/logo-ukelele-color.png', 'rb') as f:
    LOGO_COLOR = base64.b64encode(f.read()).decode()
print(f"Largo: {len(LOGO_COLOR)} chars")
```

Luego en el JSX:
```jsx
const LOGO_COLOR_B64 = "iVBORw0KGgoAAAA..."; // pegar el string completo
const LOGO_BLANCO_B64 = "iVBORw0KGgoAAAA..."; // pegar el string completo

function UkeLogo({ variant = "color", className = "" }) {
  const src = variant === "blanco" ? LOGO_BLANCO_B64 : LOGO_COLOR_B64;
  return (
    <img
      src={`data:image/png;base64,${src}`}
      alt="Ukelele Growth Company"
      className={className}
    />
  );
}
```

### Opción B: wordmark CSS (sin imagen)
Cuando el peso del base64 (~50–135KB) se quiere evitar o el logo no es crítico:

```jsx
function UkeWordmark({ variant = "color" }) {
  const fg = variant === "blanco" ? "#FFFFFF" : "#E30233";
  const sub = variant === "blanco" ? "#FFFFFF" : "#004E8A";
  return (
    <div style={{ fontFamily: "'Montserrat', sans-serif", lineHeight: 1 }}>
      <div style={{ color: fg, fontWeight: 900, fontSize: 36, letterSpacing: -0.02 }}>uke!</div>
      <div style={{ color: sub, fontWeight: 700, fontSize: 10, letterSpacing: 0.15, marginTop: 4, textTransform: "uppercase" }}>
        Ukelele Growth Company
      </div>
    </div>
  );
}
```

### Cuándo usar cada uno
- **Pieza visual donde la marca importa** (mockup para cliente, landing, reporte ejecutivo) → opción A.
- **Mini-app interna o herramienta donde solo importa que se sienta Uke** → opción B alcanza.

---

## 3. Constantes de paleta y tipografía

Definir al tope del archivo del artifact:

```jsx
const UKE = {
  rojo: "#E30233",
  rojoHover: "#C7022D",
  lavanda: "#F1EBF4",
  lavandaHover: "#E8DEEF",
  azulMedio: "#1689C0",
  azulOscuro: "#004E8A",
  purpura: "#A63D81",
  negro: "#000000",
  blanco: "#FFFFFF",
  grisCuerpo: "#444444",
  grisSuave: "#E5E5E5",
};

const FONT_DISPLAY = "'Montserrat', system-ui, sans-serif";
const FONT_BODY = "'Lato', 'Helvetica Neue', Arial, sans-serif";
```

Y un par de helpers de estilo:

```jsx
const displayStyle = (extra = {}) => ({ fontFamily: FONT_DISPLAY, ...extra });
const bodyStyle = (extra = {}) => ({ fontFamily: FONT_BODY, ...extra });
```

---

## 4. Componente Hero

```jsx
function Hero({ title, subtitle, variant = "clean", logoVariant = "color" }) {
  const bgColor = variant === "rojo" ? UKE.rojo : UKE.blanco;
  const textColor = variant === "rojo" ? UKE.blanco : UKE.negro;
  const subColor = variant === "rojo" ? UKE.blanco : UKE.grisCuerpo;

  return (
    <section
      className="px-6 md:px-12 py-20 md:py-28"
      style={{ backgroundColor: bgColor, color: textColor }}
    >
      <div className="max-w-6xl mx-auto">
        <UkeLogo variant={logoVariant} className="w-32 md:w-48 h-auto mb-12" />
        <h1
          className="font-black uppercase leading-tight mb-6"
          style={displayStyle({ fontSize: "clamp(40px, 6vw, 72px)", letterSpacing: "-0.01em" })}
        >
          {title}
        </h1>
        {subtitle && (
          <p style={bodyStyle({ fontSize: "clamp(18px, 2vw, 22px)", color: subColor, maxWidth: 720 })}>
            {subtitle}
          </p>
        )}
      </div>
    </section>
  );
}
```

---

## 5. Separador de sección

```jsx
function Separator({ title, subtitle, color = "rojo" }) {
  const bg = color === "azul" ? UKE.azulOscuro : UKE.rojo;
  return (
    <section className="px-6 md:px-12 py-16 md:py-20" style={{ backgroundColor: bg, color: UKE.blanco }}>
      <div className="max-w-6xl mx-auto">
        <h2
          className="font-black uppercase mb-4"
          style={displayStyle({ fontSize: "clamp(32px, 5vw, 48px)" })}
        >
          {title}
        </h2>
        {subtitle && (
          <p
            className="opacity-90 mb-6"
            style={bodyStyle({ fontSize: "clamp(16px, 1.8vw, 20px)", maxWidth: 720 })}
          >
            {subtitle}
          </p>
        )}
        <div className="w-20 h-1" style={{ backgroundColor: UKE.blanco }} />
      </div>
    </section>
  );
}
```

---

## 6. Big Stat

```jsx
function BigStat({ number, label }) {
  return (
    <section
      className="px-6 py-24 md:py-32 text-center"
      style={{ backgroundColor: UKE.rojo, color: UKE.blanco }}
    >
      <div
        className="font-extrabold mb-4"
        style={displayStyle({ fontSize: "clamp(72px, 12vw, 140px)", lineHeight: 1, fontWeight: 800 })}
      >
        {number}
      </div>
      <div
        className="uppercase"
        style={displayStyle({ fontSize: "clamp(16px, 2vw, 22px)", fontWeight: 600, letterSpacing: "0.1em" })}
      >
        {label}
      </div>
    </section>
  );
}
```

---

## 7. Highlights / Métricas

```jsx
function Highlights({ title, metrics }) {
  // metrics: [{value: '+47%', label: 'Sesiones vs Q2'}, ...]
  const colors = [UKE.rojo, UKE.azulOscuro, UKE.azulMedio, UKE.purpura];
  return (
    <section className="px-6 md:px-12 py-16 md:py-20">
      <div className="max-w-6xl mx-auto">
        {title && (
          <h2
            className="mb-8"
            style={displayStyle({ fontSize: "clamp(24px, 3vw, 32px)", fontWeight: 800 })}
          >
            {title}
          </h2>
        )}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {metrics.map((m, i) => {
            const color = colors[i % colors.length];
            return (
              <div key={i} className="pl-4 py-2" style={{ borderLeft: `4px solid ${color}` }}>
                <div
                  className="font-extrabold"
                  style={displayStyle({ fontSize: "clamp(40px, 5vw, 56px)", color, lineHeight: 1, fontWeight: 800 })}
                >
                  {m.value}
                </div>
                <div
                  className="uppercase mt-2"
                  style={displayStyle({ fontSize: 13, fontWeight: 600, letterSpacing: "0.05em" })}
                >
                  {m.label}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
```

---

## 8. Cards / Grid

```jsx
import { TrendingUp, Target, Users, BarChart3 } from "lucide-react";

function CardsGrid({ title, cards }) {
  // cards: [{Icon: TrendingUp, title: 'Performance', desc: '...'}, ...]
  const colors = [UKE.rojo, UKE.azulOscuro, UKE.azulMedio, UKE.purpura];
  return (
    <section className="px-6 md:px-12 py-16 md:py-20">
      <div className="max-w-6xl mx-auto">
        {title && (
          <h2
            className="mb-8"
            style={displayStyle({ fontSize: "clamp(24px, 3vw, 32px)", fontWeight: 800 })}
          >
            {title}
          </h2>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((card, i) => {
            const color = colors[i % colors.length];
            const Icon = card.Icon;
            return (
              <article
                key={i}
                className="rounded-xl p-6 transition-all duration-200 hover:-translate-y-1"
                style={{
                  backgroundColor: UKE.lavanda,
                  borderLeft: `6px solid ${color}`,
                  boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
                }}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mb-4"
                  style={{ backgroundColor: color, color: UKE.blanco }}
                >
                  {Icon && <Icon size={22} />}
                </div>
                <h3
                  className="mb-2"
                  style={displayStyle({ fontSize: 18, fontWeight: 800 })}
                >
                  {card.title}
                </h3>
                <p style={bodyStyle({ fontSize: 14, color: UKE.grisCuerpo, margin: 0 })}>
                  {card.desc}
                </p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
```

---

## 9. Comparación dos columnas

```jsx
function Compare({ left, right }) {
  // left: {label, title, items}; right: ídem
  return (
    <section className="px-6 md:px-12 py-16 md:py-20">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-8 md:p-10 rounded-xl" style={{ backgroundColor: UKE.rojo, color: UKE.blanco }}>
          <div
            className="uppercase opacity-85 mb-3"
            style={displayStyle({ fontSize: 12, fontWeight: 600, letterSpacing: "0.15em" })}
          >
            {left.label}
          </div>
          <h3
            className="mb-6"
            style={displayStyle({ fontSize: "clamp(22px, 3vw, 30px)", fontWeight: 800 })}
          >
            {left.title}
          </h3>
          <ul className="list-none p-0 m-0">
            {left.items.map((item, i) => (
              <li
                key={i}
                className="py-3 text-[15px]"
                style={{ borderBottom: i < left.items.length - 1 ? "1px solid rgba(255,255,255,0.2)" : "none" }}
              >
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="p-8 md:p-10 rounded-xl" style={{ backgroundColor: UKE.azulOscuro, color: UKE.blanco }}>
          <div
            className="uppercase opacity-85 mb-3"
            style={displayStyle({ fontSize: 12, fontWeight: 600, letterSpacing: "0.15em" })}
          >
            {right.label}
          </div>
          <h3
            className="mb-6"
            style={displayStyle({ fontSize: "clamp(22px, 3vw, 30px)", fontWeight: 800 })}
          >
            {right.title}
          </h3>
          <ul className="list-none p-0 m-0">
            {right.items.map((item, i) => (
              <li
                key={i}
                className="py-3 text-[15px]"
                style={{ borderBottom: i < right.items.length - 1 ? "1px solid rgba(255,255,255,0.2)" : "none" }}
              >
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
```

---

## 10. Iniciativas numeradas

```jsx
function Initiatives({ title, items }) {
  // items: [{title, desc}, ...]
  const colors = [UKE.rojo, UKE.azulOscuro, UKE.azulMedio];
  return (
    <section className="px-6 md:px-12 py-16 md:py-20">
      <div className="max-w-6xl mx-auto">
        {title && (
          <h2
            className="mb-12"
            style={displayStyle({ fontSize: "clamp(24px, 3vw, 32px)", fontWeight: 800 })}
          >
            {title}
          </h2>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {items.slice(0, 3).map((it, i) => {
            const color = colors[i];
            return (
              <div key={i} className="text-center">
                <div
                  className="w-16 h-16 md:w-[72px] md:h-[72px] rounded-full mx-auto mb-4 flex items-center justify-center"
                  style={{ backgroundColor: color, color: UKE.blanco }}
                >
                  <span style={displayStyle({ fontSize: 32, fontWeight: 800 })}>{i + 1}</span>
                </div>
                <h3
                  className="uppercase mb-3"
                  style={displayStyle({ fontSize: 18, fontWeight: 800, letterSpacing: "0.05em" })}
                >
                  {it.title}
                </h3>
                <p
                  className="mx-auto"
                  style={bodyStyle({ fontSize: 15, color: UKE.grisCuerpo, maxWidth: 280 })}
                >
                  {it.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
```

---

## 11. Tabla de datos

```jsx
function DataTable({ headers, rows }) {
  return (
    <div className="px-6 md:px-12 py-8">
      <div className="max-w-6xl mx-auto overflow-x-auto rounded-xl" style={{ boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
        <table className="w-full text-left" style={bodyStyle({ fontSize: 15 })}>
          <thead style={{ backgroundColor: UKE.rojo, color: UKE.blanco }}>
            <tr>
              {headers.map((h, i) => (
                <th
                  key={i}
                  className="px-4 py-3.5 uppercase"
                  style={displayStyle({ fontSize: 12, fontWeight: 600, letterSpacing: "0.05em" })}
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} style={{ backgroundColor: i % 2 === 1 ? UKE.lavanda : UKE.blanco }}>
                {row.map((cell, j) => (
                  <td key={j} className="px-4 py-3.5" style={{ borderBottom: i < rows.length - 1 ? `1px solid ${UKE.grisSuave}` : "none" }}>
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
```

---

## 12. CTA Block

```jsx
function CTA({ title, buttonText, onClick }) {
  return (
    <section className="px-6 md:px-12 py-16 md:py-20" style={{ backgroundColor: UKE.rojo, color: UKE.blanco }}>
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-6">
        <h2
          className="flex-1"
          style={displayStyle({ fontSize: "clamp(22px, 3vw, 32px)", fontWeight: 800 })}
        >
          {title}
        </h2>
        <button
          onClick={onClick}
          className="px-7 py-3.5 rounded-lg uppercase transition-all duration-200 hover:scale-105"
          style={displayStyle({
            fontSize: 14,
            fontWeight: 700,
            letterSpacing: "0.05em",
            backgroundColor: UKE.blanco,
            color: UKE.rojo,
            border: `2px solid ${UKE.blanco}`,
          })}
        >
          {buttonText}
        </button>
      </div>
    </section>
  );
}
```

---

## 13. Footer

```jsx
function Footer() {
  return (
    <footer
      className="px-6 md:px-12 py-16 md:py-20 text-center"
      style={{ backgroundColor: UKE.azulOscuro, color: UKE.blanco }}
    >
      <div className="max-w-6xl mx-auto">
        <UkeLogo variant="blanco" className="w-40 mx-auto mb-6" />
        <h2
          className="mb-4"
          style={displayStyle({ fontSize: "clamp(28px, 4vw, 44px)", fontWeight: 800 })}
        >
          ¡Muchas gracias!
        </h2>
        <p style={bodyStyle({ fontSize: 14, opacity: 0.85 })}>
          ukelele.la · @ukegrowthcompany · @ukegrowthmkt
        </p>
      </div>
    </footer>
  );
}
```

---

## 14. App de ejemplo

Combinando varios componentes — esto es lo que sería un reporte one-page completo:

```jsx
import React, { useEffect } from "react";
import { TrendingUp, Target, Users, BarChart3 } from "lucide-react";

// ... (constantes UKE, FONT_*, helpers, useUkeleleFonts, UkeLogo, etc., y todos los componentes de arriba)

export default function App() {
  useUkeleleFonts();

  return (
    <div className="min-h-screen" style={{ fontFamily: FONT_BODY, backgroundColor: UKE.blanco, color: UKE.negro }}>
      <Hero
        title="Reporte Q3 2026"
        subtitle="Performance, insights & próximos pasos"
        variant="clean"
      />

      <Separator
        title="Resultados & insights"
        subtitle="¿Qué movió la aguja este trimestre?"
        color="rojo"
      />

      <Highlights
        title="Performance del trimestre"
        metrics={[
          { value: "+47%", label: "Sesiones vs Q2" },
          { value: "$1.2M", label: "Revenue total" },
          { value: "3.4%", label: "Conversion rate" },
          { value: "12.5K", label: "Nuevos leads" },
        ]}
      />

      <BigStat number="+147%" label="Crecimiento YoY en sesiones" />

      <CardsGrid
        title="Ejes de trabajo"
        cards={[
          { Icon: TrendingUp, title: "Performance", desc: "Optimización continua de campañas paid + análisis de cohortes." },
          { Icon: Target, title: "CRO", desc: "Tests A/B mensuales sobre PDP y checkout, con priorización ICE." },
          { Icon: Users, title: "Audiencias", desc: "Segmentación RFM y reactivación lifecycle vía email + push." },
          { Icon: BarChart3, title: "Reporting", desc: "Dashboard semanal con KPIs por canal y atribución multi-touch." },
        ]}
      />

      <Initiatives
        title="Próximos pasos"
        items={[
          { title: "Diagnóstico", desc: "Auditoría UX completa del funnel y análisis de cohortes." },
          { title: "Implementación", desc: "Roadmap de tests A/B priorizados por impacto y esfuerzo." },
          { title: "Escala", desc: "Sistema de experimentación continuo y scaling de canales." },
        ]}
      />

      <Footer />
    </div>
  );
}
```

---

## Notas finales

- En artifacts, cuando un texto es muy chico el line-height de Tailwind a veces queda apretado. Si pasa, agregar `style={{ lineHeight: 1.6 }}` explícito.
- Para charts en artifacts: usar **recharts** que viene cargado por default. Colores de las series: `[UKE.rojo, UKE.azulOscuro, UKE.azulMedio, UKE.purpura]`.
- Si el artifact necesita estado local (formularios, calculadoras, simuladores), usar `useState` + `useEffect`. La paleta y tipografías son las mismas.
- **Recordar el line-height** de Lato: usar `1.6` para body, `1.1` para títulos display.
