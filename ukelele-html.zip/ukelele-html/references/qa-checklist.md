# QA Checklist Visual — Antes de entregar

Pasar este checklist sobre el output (HTML standalone o artifact React) antes de mostrar la pieza al usuario. Si algo falla, volver a iterar antes de entregar.

---

## Cómo hacer el QA

### Para HTML standalone
1. Guardar el archivo en `/mnt/user-data/outputs/`
2. Tomar screenshots en al menos dos viewports:
   - Desktop: 1280×800
   - Mobile: 390×844 (iPhone 14)
3. Revisar cada screenshot contra el checklist abajo

```bash
# En el container, usando playwright o similar:
npx playwright screenshot --viewport-size 1280,800 file:///mnt/user-data/outputs/pieza.html /tmp/screenshot-desktop.png
npx playwright screenshot --viewport-size 390,844 file:///mnt/user-data/outputs/pieza.html /tmp/screenshot-mobile.png
```

Si playwright no está disponible, usar `chromium --headless --screenshot --window-size=1280,800 file://...`.

### Para artifact React
El usuario verá el artifact renderizado en Claude.ai. Hacer una revisión mental siguiendo el código + el checklist (no se puede tomar screenshot del artifact desde el container).

---

## Checklist obligatorio

### 1. Branding e identidad
- [ ] Logo presente y embebido correctamente (no placeholder, no roto)
- [ ] Logo usa la versión correcta según el fondo (color sobre claro, blanco sobre oscuro)
- [ ] Tipografías cargadas: títulos en Montserrat, cuerpo en Lato (NO veo Times New Roman, Arial, ni system fonts en cuerpos)
- [ ] Si hay separadores de sección, son rojos `#E30233` o azul oscuro `#004E8A` (no otros colores)
- [ ] Hay al menos un uso del símbolo "&" en algún título o sección si la pieza tiene 3+ secciones

### 2. Paleta y contraste
- [ ] Todos los colores usados están en la paleta oficial (rojo, lavanda, azul medio, azul oscuro, púrpura, negro, blanco, grises)
- [ ] No hay rojo sobre azul ni azul sobre rojo (combinaciones prohibidas)
- [ ] Texto blanco solo sobre fondos: rojo, azul oscuro, negro, púrpura
- [ ] Texto negro solo sobre fondos: blanco, lavanda
- [ ] Contraste suficiente en todos los pares texto/fondo (no hay texto gris claro sobre fondo blanco que cueste leer)

### 3. Layout y estructura
- [ ] Cada sección de contenido tiene al menos UN elemento visual (dato grande, ícono, gráfico, accent de color, imagen) — no walls of text
- [ ] El espaciado vertical respira: hay suficiente padding entre secciones (mínimo 48px desktop)
- [ ] Container respeta el max-width 1200px (contenido no se estira hasta el borde de la pantalla en monitores grandes)
- [ ] Si hay grids: usan `grid-template-columns: repeat(auto-fit, minmax(...))` o `grid-cols-N` que colapsa bien en mobile

### 4. Responsive
- [ ] En mobile (390px), nada se desborda horizontalmente (no scroll horizontal)
- [ ] En mobile, los grids de cards/métricas pasan a 1 columna o 2 columnas (no 4 columnas apretadas)
- [ ] En mobile, los títulos no son ridículamente grandes (los `clamp(...)` están funcionando)
- [ ] Tablas tienen `overflow-x: auto` para scrollear horizontal si hace falta

### 5. Tipografía
- [ ] Títulos usan Montserrat ExtraBold (800) o Black (900), no Regular
- [ ] Cuerpo de texto usa Lato Regular (400), no Montserrat
- [ ] Números/stats grandes usan Montserrat ExtraBold
- [ ] Hay jerarquía visual clara: H1 > H2 > H3 > body (tamaños decrecientes y bien diferenciados)
- [ ] Letter-spacing en MAYÚSCULAS (mínimo 0.05em en uppercase, 0.1em+ en stats labels)

### 6. Detalles de calidad
- [ ] No hay textos cortados ni truncados sin querer
- [ ] No hay elementos superpuestos
- [ ] Botones/CTAs tienen padding suficiente (mínimo 12px vertical, 24px horizontal)
- [ ] Border-radius consistente (cards 12px, botones 8px)
- [ ] Sombras sutiles, no exageradas
- [ ] Si hay hover states, son sutiles (no saltos bruscos)

### 7. Cierre
- [ ] Hay un footer o cierre con datos de Ukelele (ukelele.la · @ukegrowthcompany)
- [ ] El footer usa fondo oscuro (negro o azul oscuro)
- [ ] Logo en footer es la versión blanca

---

## Errores comunes a corregir

| Síntoma | Causa probable | Fix |
|---|---|---|
| Letras con serifas en el cuerpo | Google Fonts no se cargó | Verificar `<link>` o `useUkeleleFonts()` |
| Logo se ve aplastado/distorsionado | Falta `height: auto` | Agregar `height: auto` al `<img>` |
| Card con borde grueso azul brillante | Default focus de browser | Agregar `outline: none` o estilizar focus |
| Stats de impacto sin impacto | Tamaño de fuente muy chico | Subir a 80px+ desktop, usar `clamp()` |
| Demasiado texto en cards | El usuario pidió mucho contenido | Usar bullets o partir en varias cards |
| Pieza se ve "Bootstrap" | Faltan accents de color | Agregar barras de color izquierda en cards, headers en rojo, etc. |

---

## Cuando lanzar subagente de QA

Si la pieza tiene **3+ secciones** o **5+ componentes diferentes**, lanzar subagente con la tarea:

> Mirá los screenshots adjuntos contra `references/qa-checklist.md` de la skill ukelele-html. Devolvé una lista de problemas visuales encontrados con (a) qué problema es, (b) ubicación aprox en el screenshot, (c) qué hay que cambiar para fixearlo.

Iterar el código y volver a tomar screenshots hasta que el subagente diga que pasa el checklist.
