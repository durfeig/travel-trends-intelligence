# Ukelele Growth Company — Brand Spec para Piezas Web

Este documento es la fuente única de verdad para colores, tipografías, dimensiones, layouts y reglas de diseño en HTML y React. Es paralelo y consistente con el brand-spec de la skill `ukelele-pptx`.

## Tabla de contenidos
1. [Paleta de colores](#1-paleta-de-colores)
2. [Tipografías](#2-tipografías)
3. [Layout y espaciado](#3-layout-y-espaciado)
4. [Reglas de diseño](#4-reglas-de-diseño)
5. [Catálogo de patrones](#5-catálogo-de-patrones)
6. [CSS variables base](#6-css-variables-base)

---

## 1. Paleta de colores

| Nombre | Hex | CSS var | Uso principal |
|--------|-----|---------|---------------|
| **Rojo Ukelele** | `#E30233` | `--uke-rojo` | Color primario de marca, CTAs, headers, accents fuertes, separadores |
| **Lavanda claro** | `#F1EBF4` | `--uke-lavanda` | Fondos suaves, cards alternativas, separadores discretos |
| **Azul medio** | `#1689C0` | `--uke-azul-medio` | Accents secundarios, iconos, gráficos |
| **Azul oscuro** | `#004E8A` | `--uke-azul-oscuro` | Headers oscuros, footers, accents profesionales |
| **Púrpura** | `#A63D81` | `--uke-purpura` | Tercer accent, dashboards multi-métrica |
| **Negro** | `#000000` | `--uke-negro` | Texto cuerpo, overlays sobre fotos |
| **Blanco** | `#FFFFFF` | `--uke-blanco` | Fondos de contenido, texto sobre fondos oscuros |
| **Gris cuerpo** | `#444444` | `--uke-gris-cuerpo` | Texto secundario, descripciones |
| **Gris suave** | `#E5E5E5` | `--uke-gris-suave` | Bordes, divisores, separadores sutiles |
| **Lavanda hover** | `#E8DEEF` | `--uke-lavanda-hover` | Estado hover de cards lavanda |

### Combinaciones permitidas y prohibidas

**Permitidas:**
- Texto blanco sobre fondo rojo `#E30233` ✅
- Texto blanco sobre fondo azul oscuro `#004E8A` ✅
- Texto negro sobre fondo blanco ✅
- Texto negro sobre fondo lavanda `#F1EBF4` ✅
- Texto blanco sobre negro ✅
- Texto azul oscuro `#004E8A` sobre blanco ✅
- Texto rojo `#E30233` sobre blanco o lavanda ✅

**Prohibidas:**
- Azul sobre rojo ❌
- Rojo sobre azul ❌
- Lavanda sobre blanco (sin contraste) ❌
- Cualquier combinación con ratio de contraste WCAG < 4.5 para body, < 3 para títulos grandes ❌

---

## 2. Tipografías

### Fuentes oficiales

| Elemento | Fuente | Peso | Estilo |
|----------|--------|------|--------|
| Hero / títulos de sección grandes | Montserrat | Black (900) | MAYÚSCULAS |
| Títulos de bloque | Montserrat | ExtraBold (800) | Título case o MAYÚSCULAS |
| Subtítulos / labels | Montserrat | SemiBold (600) | Variable |
| Stats grandes (números) | Montserrat | ExtraBold (800) | Grande, llamativo |
| Cuerpo de texto | Lato | Regular (400) | Normal |
| Cuerpo enfático | Lato | Bold (700) | Para énfasis |
| CTAs / botones | Montserrat | Bold (700) | MAYÚSCULAS, letter-spacing 0.05em |

### Import desde Google Fonts

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&family=Lato:wght@400;700;900&display=swap" rel="stylesheet">
```

### Tamaños recomendados (desktop, mobile entre paréntesis)

| Elemento | Tamaño desktop | Tamaño mobile | Line-height |
|----------|---------------|---------------|-------------|
| Hero title (H1) | 56–80px | 36–48px | 1.05 |
| Sección title (H2) | 36–48px | 28–32px | 1.1 |
| Bloque title (H3) | 24–32px | 22–24px | 1.15 |
| Subtítulo | 18–22px | 16–18px | 1.3 |
| Big stat (número) | 80–120px | 56–72px | 1.0 |
| Stat label | 14–18px | 13–14px | 1.2 |
| Body | 16–18px | 15–16px | 1.6 |
| Caption / meta | 12–14px | 11–13px | 1.4 |

### Regla tipográfica clave

> **Montserrat para impacto** (títulos, stats, separadores, CTAs).
> **Lato para legibilidad** (cuerpo, descripciones, tablas largas).
> NUNCA usar Montserrat para párrafos largos — se ve apretado y pesado.

---

## 3. Layout y espaciado

### Grid base
- **Container max-width**: 1200px (centered, padding lateral 24px desktop / 16px mobile)
- **Hero / full-bleed sections**: 100vw, contenido interior limitado a 1200px
- **Gutters de grid**: 24px desktop, 16px mobile

### Espaciado vertical (sistema 8px)
| Token | Valor | Uso |
|-------|-------|-----|
| `--uke-space-xs` | 8px | espacios mínimos, separar label-value |
| `--uke-space-sm` | 16px | padding de cards chicas |
| `--uke-space-md` | 24px | padding de cards estándar, gap de grids |
| `--uke-space-lg` | 48px | separación entre bloques de contenido |
| `--uke-space-xl` | 80px | separación entre secciones |
| `--uke-space-2xl` | 120px | separación entre secciones tipo hero/separador |

### Border-radius
- **Cards estándar**: 12px
- **Botones / CTAs**: 8px
- **Pills / badges**: 999px (full radius)
- **Imágenes hero**: 0 (cuadradas, full-bleed)

### Sombras
- **Cards estáticas**: `0 2px 8px rgba(0, 0, 0, 0.06)`
- **Cards hover / elevated**: `0 8px 24px rgba(0, 0, 0, 0.10)`
- **Modales / overlays**: `0 16px 48px rgba(0, 0, 0, 0.18)`

### Responsive breakpoints
- Mobile: ≤ 640px
- Tablet: 641–1024px
- Desktop: ≥ 1025px

Mobile-first: la página debe verse y funcionar bien en mobile primero, luego escalar.

---

## 4. Reglas de diseño

### Logo
- Sobre fondo claro (blanco, lavanda, gris claro): logo **color** (`logo-ukelele-color.png`)
- Sobre fondo oscuro (rojo, azul oscuro, negro): logo **blanco** (`logo-ukelele-blanco.png`)
- Tamaño mínimo: 80px de ancho (debajo no se lee "UKELELE GROWTH COMPANY")
- Tamaño en header/nav: 100–140px
- Tamaño en hero: 180–240px

### Uso del símbolo "&"
- Característico de Ukelele. Usarlo en títulos cuando corresponda: "INSIGHTS & RECOMENDACIONES", "DATOS & APRENDIZAJES".

### Fondos de secciones
- **Contenido general**: fondo blanco
- **Separadores de sección**: fondo rojo `#E30233` o azul oscuro `#004E8A`
- **Stats de impacto**: fondo rojo `#E30233`
- **Hero/portada**: imagen de fondo + overlay negro al 40–60% de opacidad
- **Cierre**: fondo oscuro (negro o azul oscuro)
- **Cards alternativas**: fondo lavanda `#F1EBF4`

### Iconos
- Estilo: línea fina (thin line). Recomendado: Lucide Icons (`lucide-react` en React, `<i data-lucide="...">` en HTML con CDN).
- Tamaño en cards: 24–32px. Color: rojo, azul medio, azul oscuro o púrpura.
- En stats grandes: 40–48px, mismo color que el número.

### Elementos visuales obligatorios
Cada sección/bloque de contenido debe tener al menos UN elemento visual: dato grande, ícono, gráfico, imagen, o accent de color. **Prohibido**: secciones con solo texto en bullets sobre fondo blanco sin nada visual.

### Animaciones
- Mantener simples y sutiles. Hover en cards: leve elevación (translateY -2px) + sombra más fuerte. Transiciones 200–300ms ease.
- En artifacts React, usar `transition-all duration-200` de Tailwind.
- Evitar animaciones llamativas que distraigan (no hacer carousels que se mueven solos, no autoplay de cosas).

---

## 5. Catálogo de patrones

Cada pieza web se compone de bloques de estos patrones. La implementación HTML+CSS y React+Tailwind está en `html-patterns.md` y `react-patterns.md`.

### 5.1 Hero / Portada
Banner full-width con título grande, subtítulo opcional, CTA opcional. Variantes:
- **Hero limpio**: fondo blanco, título Montserrat Black, accent en rojo (línea o palabra)
- **Hero rojo**: fondo rojo sólido, texto blanco, contundente
- **Hero con foto**: imagen full-bleed + overlay oscuro 40–60% + texto blanco encima

### 5.2 Separador de sección
Banda horizontal full-width que introduce una nueva sección.
- Fondo: rojo `#E30233` o azul oscuro `#004E8A`
- Título: Montserrat Black, blanco, 36–48px, ALL CAPS
- Subtítulo opcional: Lato, blanco, 18–20px (pregunta o contexto)
- Línea decorativa blanca debajo del título (60–120px de ancho)

### 5.3 Big Stat (número de impacto)
Bloque dedicado a UN número.
- Fondo: rojo `#E30233` (variante: blanco con número en rojo)
- Número: Montserrat ExtraBold, blanco (o rojo), 80–120px
- Label: Montserrat SemiBold, blanco (o negro), 16–22px, ALL CAPS, letter-spacing 0.1em

### 5.4 Highlights / Métricas múltiples
3–4 stats en fila (desktop) o stacked (mobile).
- Cada métrica: número grande en rojo + label en negro debajo
- Layout: CSS grid 3 o 4 columnas, gap 24px
- Centrado o alineado izquierda según el tono

### 5.5 Cards / Grid
Grilla de cards (2×2 o 3 columnas) con ícono + título + descripción.
- Card: fondo lavanda `#F1EBF4` o blanco con borde gris
- Barra de color izquierda (4–8px) en uno de los colores de la paleta — rotar entre rojo / azul oscuro / azul medio / púrpura
- Título: Montserrat ExtraBold, negro, 16–18px
- Descripción: Lato, gris cuerpo, 14–16px

### 5.6 Comparación dos columnas
Antes/después, problema/solución, presente/futuro.
- Columna 1: fondo rojo `#E30233`, texto blanco — situación actual/negativa
- Columna 2: fondo azul oscuro `#004E8A` o azul medio `#1689C0`, texto blanco — futuro/positivo
- Cada columna: título grande + 3–5 bullets

### 5.7 Roadmap / Timeline
Línea de tiempo horizontal (desktop) o vertical (mobile).
- Bloques de fase con header en rojo / azul / púrpura (rotar)
- Cada fase: label arriba, lista de iniciativas dentro de cards lavanda
- Conector: línea continua o flecha entre fases

### 5.8 Tabla de datos
- Header: fondo rojo `#E30233` o azul oscuro `#004E8A`, texto blanco, Montserrat SemiBold
- Filas: alternar blanco y lavanda `#F1EBF4` (zebra striping)
- Texto celdas: Lato, negro, 14–15px
- Separación celdas: padding 12–16px

### 5.9 Iniciativas numeradas (1-2-3)
3 iniciativas o pasos en columnas, cada una con número grande en círculo de color.
- Círculo: 64px, fondo rojo / azul oscuro / azul medio (rotando)
- Número en blanco dentro del círculo: Montserrat ExtraBold, 32px
- Título de iniciativa debajo: Montserrat ExtraBold, negro, 16–18px, ALL CAPS
- Descripción: Lato, gris cuerpo, 14–15px

### 5.10 CTA Block
Bloque de llamada a la acción.
- Fondo: rojo `#E30233` o azul oscuro `#004E8A`
- Título grande blanco + botón
- Botón: fondo blanco, texto rojo o azul oscuro, padding 16px 32px, border-radius 8px, Montserrat Bold MAYÚSCULAS

### 5.11 Footer / Cierre
- Fondo: negro o azul oscuro
- Logo blanco centrado (versión `logo-ukelele-blanco.png`)
- Texto: "Muchas gracias" / "Hablemos" / similar, Montserrat ExtraBold, blanco, 32–48px
- Datos de contacto: ukelele.la · @ukegrowthcompany · @ukegrowthmkt — Lato, blanco, 13–14px

### 5.12 Form / Input (para mini-apps)
- Inputs: border 1.5px gris suave, border-radius 8px, padding 12px 16px, font Lato 16px, focus border rojo `#E30233`
- Labels: Montserrat SemiBold, negro, 13px, MAYÚSCULAS, letter-spacing 0.05em, mb 8px
- Botón submit: fondo rojo, texto blanco, hover oscurece a `#C7022D`

---

## 6. CSS variables base

Este bloque debe ir en TODO HTML standalone. En React/Tailwind se mapea como custom theme (ver `react-patterns.md`).

```css
:root {
  /* Colores */
  --uke-rojo: #E30233;
  --uke-rojo-hover: #C7022D;
  --uke-lavanda: #F1EBF4;
  --uke-lavanda-hover: #E8DEEF;
  --uke-azul-medio: #1689C0;
  --uke-azul-oscuro: #004E8A;
  --uke-purpura: #A63D81;
  --uke-negro: #000000;
  --uke-blanco: #FFFFFF;
  --uke-gris-cuerpo: #444444;
  --uke-gris-suave: #E5E5E5;

  /* Tipografías */
  --uke-font-display: 'Montserrat', system-ui, -apple-system, sans-serif;
  --uke-font-body: 'Lato', 'Helvetica Neue', Arial, sans-serif;

  /* Espaciado */
  --uke-space-xs: 8px;
  --uke-space-sm: 16px;
  --uke-space-md: 24px;
  --uke-space-lg: 48px;
  --uke-space-xl: 80px;
  --uke-space-2xl: 120px;

  /* Radios */
  --uke-radius-sm: 8px;
  --uke-radius-md: 12px;
  --uke-radius-pill: 999px;

  /* Sombras */
  --uke-shadow-card: 0 2px 8px rgba(0, 0, 0, 0.06);
  --uke-shadow-elevated: 0 8px 24px rgba(0, 0, 0, 0.10);

  /* Container */
  --uke-container-max: 1200px;
  --uke-container-padding: 24px;
}

@media (max-width: 640px) {
  :root {
    --uke-container-padding: 16px;
    --uke-space-lg: 32px;
    --uke-space-xl: 56px;
    --uke-space-2xl: 80px;
  }
}

/* Reset mínimo */
*, *::before, *::after { box-sizing: border-box; }
body {
  margin: 0;
  font-family: var(--uke-font-body);
  font-size: 16px;
  line-height: 1.6;
  color: var(--uke-negro);
  background: var(--uke-blanco);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
h1, h2, h3, h4, h5 {
  font-family: var(--uke-font-display);
  font-weight: 800;
  line-height: 1.1;
  margin: 0 0 var(--uke-space-md) 0;
}
p { margin: 0 0 var(--uke-space-sm) 0; }
img { max-width: 100%; height: auto; display: block; }
a { color: var(--uke-rojo); text-decoration: none; }
a:hover { text-decoration: underline; }

/* Container */
.uke-container {
  max-width: var(--uke-container-max);
  margin: 0 auto;
  padding-left: var(--uke-container-padding);
  padding-right: var(--uke-container-padding);
}

/* Botón base */
.uke-btn {
  display: inline-block;
  padding: 14px 28px;
  font-family: var(--uke-font-display);
  font-weight: 700;
  font-size: 14px;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  border-radius: var(--uke-radius-sm);
  border: none;
  cursor: pointer;
  transition: all 200ms ease;
}
.uke-btn-primary {
  background: var(--uke-rojo);
  color: var(--uke-blanco);
}
.uke-btn-primary:hover {
  background: var(--uke-rojo-hover);
  text-decoration: none;
}
.uke-btn-secondary {
  background: var(--uke-blanco);
  color: var(--uke-rojo);
  border: 2px solid var(--uke-rojo);
}
.uke-btn-secondary:hover {
  background: var(--uke-rojo);
  color: var(--uke-blanco);
  text-decoration: none;
}
```

---

## Notas de implementación

- **Si Lato no carga**: el fallback `Helvetica Neue, Arial, sans-serif` ya está en `--uke-font-body`. No hay otra acción necesaria.
- **Imágenes de fondo en hero**: usar `background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('...') center/cover`.
- **Tablas en HTML**: siempre wrapper con `overflow-x: auto` para mobile.
- **Charts**: si necesita gráficos, usar Recharts (en React) o Chart.js (en HTML standalone con CDN). Colores: rotar entre rojo, azul oscuro, azul medio, púrpura.
- **Iconos**: Lucide es la librería preferida. CDN para HTML: `https://unpkg.com/lucide@latest/dist/umd/lucide.min.js`.
