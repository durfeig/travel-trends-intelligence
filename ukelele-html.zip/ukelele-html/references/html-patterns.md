# HTML Standalone — Patrones copy-paste

Snippets de HTML+CSS para cada patrón del catálogo. Todos asumen que las CSS variables y reset base de `brand-spec.md` están cargados.

## Tabla de contenidos
1. [Esqueleto base de un HTML Ukelele](#1-esqueleto-base)
2. [Embeber el logo en base64](#2-embeber-el-logo-en-base64)
3. [Hero / Portada](#3-hero--portada)
4. [Separador de sección](#4-separador-de-sección)
5. [Big Stat](#5-big-stat)
6. [Highlights / Métricas múltiples](#6-highlights--métricas-múltiples)
7. [Cards / Grid](#7-cards--grid)
8. [Comparación dos columnas](#8-comparación-dos-columnas)
9. [Iniciativas numeradas](#9-iniciativas-numeradas)
10. [Tabla de datos](#10-tabla-de-datos)
11. [CTA Block](#11-cta-block)
12. [Footer / Cierre](#12-footer--cierre)

---

## 1. Esqueleto base

```html
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Título de la pieza · Ukelele</title>

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&family=Lato:wght@400;700;900&display=swap" rel="stylesheet">

  <!-- Lucide icons (opcional) -->
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>

  <style>
    /* === PEGAR ACÁ TODO EL BLOQUE DE CSS BASE de brand-spec.md sección 6 === */

    /* === Estilos específicos de esta pieza === */
  </style>
</head>
<body>

  <!-- Secciones de la pieza acá -->

  <script>
    // Activar lucide icons si se usan
    if (typeof lucide !== 'undefined') lucide.createIcons();
  </script>
</body>
</html>
```

---

## 2. Embeber el logo en base64

Antes de generar el HTML, en bash:

```bash
LOGO_COLOR_B64=$(base64 -w 0 /mnt/skills/user/ukelele-html/assets/logo-ukelele-color.png)
LOGO_BLANCO_B64=$(base64 -w 0 /mnt/skills/user/ukelele-html/assets/logo-ukelele-blanco.png)
```

O en Python:

```python
import base64
with open('/mnt/skills/user/ukelele-html/assets/logo-ukelele-color.png', 'rb') as f:
    logo_color_b64 = base64.b64encode(f.read()).decode()
with open('/mnt/skills/user/ukelele-html/assets/logo-ukelele-blanco.png', 'rb') as f:
    logo_blanco_b64 = base64.b64encode(f.read()).decode()
```

Luego inyectar en el HTML:

```html
<img src="data:image/png;base64,IIIBASE64_AQUIIII" alt="Ukelele Growth Company" class="uke-logo">
```

Estilos del logo:

```css
.uke-logo {
  width: 120px;
  height: auto;
}
.uke-logo--hero { width: 200px; }
.uke-logo--footer { width: 160px; }
```

---

## 3. Hero / Portada

### Variante A: Hero limpio (fondo blanco)

```html
<section class="uke-hero uke-hero--clean">
  <div class="uke-container">
    <img src="data:image/png;base64,..." alt="Ukelele" class="uke-logo">
    <h1 class="uke-hero__title">Reporte trimestral <span class="uke-accent">Q3 2026</span></h1>
    <p class="uke-hero__subtitle">Performance, insights & próximos pasos</p>
  </div>
</section>
```

```css
.uke-hero { padding: var(--uke-space-2xl) 0 var(--uke-space-xl); }
.uke-hero--clean { background: var(--uke-blanco); }
.uke-hero__title {
  font-size: clamp(40px, 6vw, 72px);
  font-weight: 900;
  font-family: var(--uke-font-display);
  text-transform: uppercase;
  margin: var(--uke-space-lg) 0 var(--uke-space-md);
  letter-spacing: -0.01em;
}
.uke-hero__subtitle {
  font-size: clamp(18px, 2vw, 22px);
  color: var(--uke-gris-cuerpo);
  max-width: 720px;
}
.uke-accent { color: var(--uke-rojo); }
```

### Variante B: Hero rojo

```html
<section class="uke-hero uke-hero--rojo">
  <div class="uke-container">
    <img src="data:image/png;base64,..." alt="Ukelele" class="uke-logo uke-logo--hero">
    <h1 class="uke-hero__title">Crecimiento sostenido<br>en cada canal</h1>
    <p class="uke-hero__subtitle">Datos & aprendizajes del último trimestre</p>
  </div>
</section>
```

```css
.uke-hero--rojo {
  background: var(--uke-rojo);
  color: var(--uke-blanco);
}
.uke-hero--rojo .uke-hero__subtitle { color: var(--uke-blanco); opacity: 0.9; }
```

### Variante C: Hero con foto + overlay

```html
<section class="uke-hero uke-hero--foto" style="background-image: linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)), url('https://...');">
  <div class="uke-container">
    <img src="data:image/png;base64,LOGO_BLANCO_B64" alt="Ukelele" class="uke-logo uke-logo--hero">
    <h1 class="uke-hero__title">Brief estratégico 2026</h1>
    <p class="uke-hero__subtitle">Cliente: Acme S.A.</p>
  </div>
</section>
```

```css
.uke-hero--foto {
  background-size: cover;
  background-position: center;
  color: var(--uke-blanco);
  min-height: 480px;
  display: flex;
  align-items: center;
}
.uke-hero--foto .uke-hero__subtitle { color: var(--uke-blanco); opacity: 0.9; }
```

---

## 4. Separador de sección

```html
<section class="uke-separator">
  <div class="uke-container">
    <h2 class="uke-separator__title">Resultados & insights</h2>
    <p class="uke-separator__subtitle">¿Qué movió la aguja este trimestre?</p>
    <div class="uke-separator__line"></div>
  </div>
</section>
```

```css
.uke-separator {
  background: var(--uke-rojo);  /* o var(--uke-azul-oscuro) */
  color: var(--uke-blanco);
  padding: var(--uke-space-xl) 0;
}
.uke-separator__title {
  font-size: clamp(32px, 5vw, 48px);
  font-weight: 900;
  text-transform: uppercase;
  margin: 0 0 var(--uke-space-md);
}
.uke-separator__subtitle {
  font-size: clamp(16px, 1.8vw, 20px);
  font-family: var(--uke-font-body);
  font-weight: 400;
  opacity: 0.9;
  max-width: 720px;
  margin-bottom: var(--uke-space-md);
}
.uke-separator__line {
  width: 80px;
  height: 4px;
  background: var(--uke-blanco);
}
```

---

## 5. Big Stat

```html
<section class="uke-bigstat">
  <div class="uke-bigstat__number">+147%</div>
  <div class="uke-bigstat__label">Crecimiento YoY en sesiones</div>
</section>
```

```css
.uke-bigstat {
  background: var(--uke-rojo);
  color: var(--uke-blanco);
  padding: var(--uke-space-2xl) var(--uke-container-padding);
  text-align: center;
}
.uke-bigstat__number {
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: clamp(72px, 12vw, 140px);
  line-height: 1;
  margin-bottom: var(--uke-space-md);
}
.uke-bigstat__label {
  font-family: var(--uke-font-display);
  font-weight: 600;
  font-size: clamp(16px, 2vw, 22px);
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
```

---

## 6. Highlights / Métricas múltiples

```html
<section class="uke-highlights">
  <div class="uke-container">
    <h2 class="uke-section-title">Performance del trimestre</h2>
    <div class="uke-highlights__grid">
      <div class="uke-metric">
        <div class="uke-metric__value">+47%</div>
        <div class="uke-metric__label">Sesiones vs Q2</div>
      </div>
      <div class="uke-metric">
        <div class="uke-metric__value">$1.2M</div>
        <div class="uke-metric__label">Revenue total</div>
      </div>
      <div class="uke-metric">
        <div class="uke-metric__value">3.4%</div>
        <div class="uke-metric__label">Conversion rate</div>
      </div>
      <div class="uke-metric">
        <div class="uke-metric__value">12.5K</div>
        <div class="uke-metric__label">Nuevos leads</div>
      </div>
    </div>
  </div>
</section>
```

```css
.uke-highlights { padding: var(--uke-space-xl) 0; }
.uke-section-title {
  font-size: clamp(24px, 3vw, 32px);
  font-weight: 800;
  font-family: var(--uke-font-display);
  margin-bottom: var(--uke-space-lg);
}
.uke-highlights__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: var(--uke-space-md);
}
.uke-metric {
  padding: var(--uke-space-md);
  text-align: left;
  border-left: 4px solid var(--uke-rojo);
}
.uke-metric:nth-child(2) { border-left-color: var(--uke-azul-oscuro); }
.uke-metric:nth-child(3) { border-left-color: var(--uke-azul-medio); }
.uke-metric:nth-child(4) { border-left-color: var(--uke-purpura); }
.uke-metric__value {
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: clamp(40px, 5vw, 56px);
  color: var(--uke-rojo);
  line-height: 1;
}
.uke-metric:nth-child(2) .uke-metric__value { color: var(--uke-azul-oscuro); }
.uke-metric:nth-child(3) .uke-metric__value { color: var(--uke-azul-medio); }
.uke-metric:nth-child(4) .uke-metric__value { color: var(--uke-purpura); }
.uke-metric__label {
  font-family: var(--uke-font-display);
  font-weight: 600;
  font-size: 13px;
  color: var(--uke-negro);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-top: var(--uke-space-xs);
}
```

---

## 7. Cards / Grid

```html
<section class="uke-cards-section">
  <div class="uke-container">
    <h2 class="uke-section-title">Ejes de trabajo</h2>
    <div class="uke-cards-grid">
      <article class="uke-card">
        <div class="uke-card__icon"><i data-lucide="trending-up"></i></div>
        <h3 class="uke-card__title">Performance</h3>
        <p class="uke-card__desc">Optimización continua de campañas paid + análisis cohortes.</p>
      </article>
      <article class="uke-card">
        <div class="uke-card__icon"><i data-lucide="target"></i></div>
        <h3 class="uke-card__title">CRO</h3>
        <p class="uke-card__desc">Tests A/B mensuales sobre PDP y checkout, con priorización ICE.</p>
      </article>
      <article class="uke-card">
        <div class="uke-card__icon"><i data-lucide="users"></i></div>
        <h3 class="uke-card__title">Audiencias</h3>
        <p class="uke-card__desc">Segmentación RFM y reactivación lifecycle vía email + push.</p>
      </article>
      <article class="uke-card">
        <div class="uke-card__icon"><i data-lucide="bar-chart-3"></i></div>
        <h3 class="uke-card__title">Reporting</h3>
        <p class="uke-card__desc">Dashboard semanal con KPIs por canal y atribución multi-touch.</p>
      </article>
    </div>
  </div>
</section>
```

```css
.uke-cards-section { padding: var(--uke-space-xl) 0; }
.uke-cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: var(--uke-space-md);
}
.uke-card {
  position: relative;
  padding: var(--uke-space-md);
  background: var(--uke-lavanda);
  border-radius: var(--uke-radius-md);
  border-left: 6px solid var(--uke-rojo);
  transition: all 200ms ease;
}
.uke-card:nth-child(2) { border-left-color: var(--uke-azul-oscuro); }
.uke-card:nth-child(3) { border-left-color: var(--uke-azul-medio); }
.uke-card:nth-child(4) { border-left-color: var(--uke-purpura); }
.uke-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--uke-shadow-elevated);
  background: var(--uke-lavanda-hover);
}
.uke-card__icon {
  width: 48px; height: 48px;
  border-radius: 50%;
  background: var(--uke-rojo);
  color: var(--uke-blanco);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: var(--uke-space-sm);
}
.uke-card:nth-child(2) .uke-card__icon { background: var(--uke-azul-oscuro); }
.uke-card:nth-child(3) .uke-card__icon { background: var(--uke-azul-medio); }
.uke-card:nth-child(4) .uke-card__icon { background: var(--uke-purpura); }
.uke-card__title {
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: 18px;
  margin: 0 0 var(--uke-space-xs);
}
.uke-card__desc {
  font-size: 14px;
  color: var(--uke-gris-cuerpo);
  margin: 0;
}
```

---

## 8. Comparación dos columnas

```html
<section class="uke-compare">
  <div class="uke-container uke-compare__grid">
    <div class="uke-compare__col uke-compare__col--neg">
      <div class="uke-compare__label">Presente</div>
      <h3 class="uke-compare__title">El problema actual</h3>
      <ul class="uke-compare__list">
        <li>Conversión por debajo del 1.5%</li>
        <li>CAC creciendo 12% MoM</li>
        <li>Retención de 30 días en 22%</li>
      </ul>
    </div>
    <div class="uke-compare__col uke-compare__col--pos">
      <div class="uke-compare__label">Futuro</div>
      <h3 class="uke-compare__title">Hacia dónde vamos</h3>
      <ul class="uke-compare__list">
        <li>Conversión sostenida en 3%+</li>
        <li>CAC reducido vía orgánico</li>
        <li>Retención > 40%</li>
      </ul>
    </div>
  </div>
</section>
```

```css
.uke-compare { padding: var(--uke-space-xl) 0; }
.uke-compare__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--uke-space-md);
}
@media (max-width: 768px) {
  .uke-compare__grid { grid-template-columns: 1fr; }
}
.uke-compare__col {
  padding: var(--uke-space-lg);
  border-radius: var(--uke-radius-md);
  color: var(--uke-blanco);
}
.uke-compare__col--neg { background: var(--uke-rojo); }
.uke-compare__col--pos { background: var(--uke-azul-oscuro); }
.uke-compare__label {
  font-family: var(--uke-font-display);
  font-weight: 600;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  opacity: 0.85;
  margin-bottom: var(--uke-space-sm);
}
.uke-compare__title {
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: clamp(22px, 3vw, 30px);
  margin: 0 0 var(--uke-space-md);
  color: var(--uke-blanco);
}
.uke-compare__list {
  list-style: none;
  padding: 0;
  margin: 0;
}
.uke-compare__list li {
  padding: 10px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
}
.uke-compare__list li:last-child { border-bottom: none; }
```

---

## 9. Iniciativas numeradas

```html
<section class="uke-initiatives">
  <div class="uke-container">
    <h2 class="uke-section-title">Próximos pasos</h2>
    <div class="uke-initiatives__grid">
      <div class="uke-initiative">
        <div class="uke-initiative__num">1</div>
        <h3 class="uke-initiative__title">Diagnóstico</h3>
        <p class="uke-initiative__desc">Auditoría UX completa del funnel y análisis de cohortes.</p>
      </div>
      <div class="uke-initiative">
        <div class="uke-initiative__num">2</div>
        <h3 class="uke-initiative__title">Implementación</h3>
        <p class="uke-initiative__desc">Roadmap de tests A/B priorizados por impacto y esfuerzo.</p>
      </div>
      <div class="uke-initiative">
        <div class="uke-initiative__num">3</div>
        <h3 class="uke-initiative__title">Escala</h3>
        <p class="uke-initiative__desc">Sistema de experimentación continuo y scaling de canales.</p>
      </div>
    </div>
  </div>
</section>
```

```css
.uke-initiatives { padding: var(--uke-space-xl) 0; }
.uke-initiatives__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--uke-space-lg);
}
.uke-initiative { text-align: center; }
.uke-initiative__num {
  width: 72px; height: 72px;
  border-radius: 50%;
  background: var(--uke-rojo);
  color: var(--uke-blanco);
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: 36px;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto var(--uke-space-md);
}
.uke-initiative:nth-child(2) .uke-initiative__num { background: var(--uke-azul-oscuro); }
.uke-initiative:nth-child(3) .uke-initiative__num { background: var(--uke-azul-medio); }
.uke-initiative__title {
  font-family: var(--uke-font-display);
  font-weight: 800;
  text-transform: uppercase;
  font-size: 18px;
  letter-spacing: 0.05em;
  margin: 0 0 var(--uke-space-sm);
}
.uke-initiative__desc {
  font-size: 15px;
  color: var(--uke-gris-cuerpo);
  max-width: 280px;
  margin: 0 auto;
}
```

---

## 10. Tabla de datos

```html
<div class="uke-table-wrap">
  <table class="uke-table">
    <thead>
      <tr>
        <th>Canal</th>
        <th>Sesiones</th>
        <th>Conv. Rate</th>
        <th>Revenue</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Google Ads</td>
        <td>48,210</td>
        <td>3.2%</td>
        <td>$420K</td>
      </tr>
      <tr>
        <td>Meta Ads</td>
        <td>32,540</td>
        <td>2.8%</td>
        <td>$280K</td>
      </tr>
      <tr>
        <td>Orgánico</td>
        <td>67,800</td>
        <td>4.1%</td>
        <td>$510K</td>
      </tr>
    </tbody>
  </table>
</div>
```

```css
.uke-table-wrap {
  overflow-x: auto;
  border-radius: var(--uke-radius-md);
  box-shadow: var(--uke-shadow-card);
}
.uke-table {
  width: 100%;
  border-collapse: collapse;
  font-family: var(--uke-font-body);
  font-size: 15px;
}
.uke-table thead {
  background: var(--uke-rojo);
  color: var(--uke-blanco);
}
.uke-table th {
  font-family: var(--uke-font-display);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  font-size: 12px;
  padding: 14px 16px;
  text-align: left;
}
.uke-table td {
  padding: 14px 16px;
  border-bottom: 1px solid var(--uke-gris-suave);
}
.uke-table tbody tr:nth-child(even) { background: var(--uke-lavanda); }
.uke-table tbody tr:last-child td { border-bottom: none; }
```

---

## 11. CTA Block

```html
<section class="uke-cta">
  <div class="uke-container uke-cta__inner">
    <h2 class="uke-cta__title">¿Hablamos sobre tu próximo proyecto?</h2>
    <a href="mailto:hola@ukelele.la" class="uke-btn uke-btn-secondary">Escribinos</a>
  </div>
</section>
```

```css
.uke-cta {
  background: var(--uke-rojo);
  padding: var(--uke-space-xl) 0;
  color: var(--uke-blanco);
}
.uke-cta__inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--uke-space-md);
  flex-wrap: wrap;
}
.uke-cta__title {
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: clamp(22px, 3vw, 32px);
  margin: 0;
  flex: 1 1 auto;
}
```

---

## 12. Footer / Cierre

```html
<footer class="uke-footer">
  <div class="uke-container uke-footer__inner">
    <img src="data:image/png;base64,LOGO_BLANCO_B64" alt="Ukelele Growth Company" class="uke-logo uke-logo--footer">
    <h2 class="uke-footer__title">¡Muchas gracias!</h2>
    <p class="uke-footer__contact">ukelele.la · @ukegrowthcompany · @ukegrowthmkt</p>
  </div>
</footer>
```

```css
.uke-footer {
  background: var(--uke-azul-oscuro); /* o var(--uke-negro) */
  color: var(--uke-blanco);
  padding: var(--uke-space-xl) 0;
  text-align: center;
}
.uke-footer__inner > * + * { margin-top: var(--uke-space-md); }
.uke-footer__title {
  font-family: var(--uke-font-display);
  font-weight: 800;
  font-size: clamp(28px, 4vw, 44px);
  margin: 0;
}
.uke-footer__contact {
  font-family: var(--uke-font-body);
  font-size: 14px;
  opacity: 0.85;
  margin: 0;
}
```

---

## Checklist al terminar

- [ ] Todas las CSS variables están definidas
- [ ] Google Fonts importadas (Montserrat + Lato)
- [ ] Logo embebido como base64 (color o blanco según corresponda)
- [ ] Cada sección tiene al menos 1 elemento visual (no walls of text)
- [ ] Combinaciones de color respetan las reglas (no rojo sobre azul, etc.)
- [ ] Responsive funciona: media query mobile probada
- [ ] Sin texto desbordando ni overflows
- [ ] Footer con datos de contacto presentes
