---
name: ukelele-html
description: >
  Crea piezas web (archivos HTML standalone, artifacts React/JSX, dashboards, reportes one-page,
  landing pages, mini-apps, mockups) con la identidad visual oficial de Ukelele Growth Company.
  Usar SIEMPRE cuando el usuario de Ukelele pida: armar un HTML, hacer un artifact, crear un
  dashboard, una landing, un reporte web, un mockup interactivo, una mini-app o calculadora,
  un artifact de React, o cualquier pieza visual web que deba seguir el estilo de Ukelele.
  También activar cuando diga "haceme un HTML con el estilo de Uke", "armame un artifact con
  nuestra identidad", "ponele branding de Uke", "que tenga la onda Ukelele", o cualquier
  pedido de pieza web/artifact que mencione la marca. Esta skill incluye toda la paleta,
  tipografías, layouts, logos PNG (color y blanco), y snippets HTML+CSS y JSX+Tailwind oficiales.
---

# Skill: Piezas Web Ukelele (HTML + React)

Esta skill produce piezas web 100% alineadas con la identidad visual de Ukelele Growth Company. Cubre dos formatos:

1. **HTML standalone** — un archivo `.html` autocontenido (CSS embebido, logo embebido como base64) que el usuario puede abrir en el navegador o compartir.
2. **Artifact React/JSX** — componente React con Tailwind para renderizar dentro de Claude.ai.

La paleta, jerarquía tipográfica y patrones de layout son los **mismos** que usa la skill `ukelele-pptx` — se busca consistencia total entre presentaciones y piezas web.

---

## Flujo de trabajo

1. **Entender el pedido**: ¿qué pieza es (reporte, dashboard, landing, mini-app)? ¿Estática o interactiva? ¿HTML standalone o artifact React? Si no queda claro, preferir HTML standalone para reportes/dashboards y React para mini-apps interactivas.
2. **Leer la referencia de marca**: leer SIEMPRE `references/brand-spec.md` antes de escribir código. Si el pedido es un artifact React, leer también `references/react-patterns.md`.
3. **Planificar la estructura**: definir secciones (hero/portada, separadores, contenido, stats, cierre) y elegir patrones del brand-spec para cada una.
4. **Generar el código**: HTML+CSS o JSX+Tailwind según el caso, siguiendo estrictamente las specs.
5. **Embeber el logo correctamente** (ver sección Logo abajo).
6. **QA visual**: tomar screenshot del HTML renderizado y revisar contra el checklist (`references/qa-checklist.md`). Si hay 3+ secciones, lanzar subagente de QA si está disponible.
7. **Entregar**: presentar el archivo o artifact al usuario.

---

## Referencias de la skill

Leer en este orden según el caso de uso:

| Archivo | Cuándo leerlo |
|---|---|
| `references/brand-spec.md` | **Siempre.** Paleta, tipografías, layouts y reglas de marca. |
| `references/html-patterns.md` | Cuando se está haciendo HTML standalone. Snippets copy-paste. |
| `references/react-patterns.md` | Cuando se está haciendo artifact React. Componentes JSX + Tailwind config. |
| `references/qa-checklist.md` | Antes de entregar. Checklist visual obligatorio. |

---

## Logo

Esta skill incluye dos versiones del logo en `assets/`:

- `assets/logo-ukelele-color.png` — versión a color (rojo + azul oscuro). Usar sobre fondos **claros**: blanco, lavanda, gris claro.
- `assets/logo-ukelele-blanco.png` — versión negativa (blanco). Usar sobre fondos **oscuros**: rojo `#E30233`, azul oscuro `#004E8A`, negro.

### Cómo embeber el logo

**HTML standalone (recomendado: base64 inline)**: convertir el PNG a base64 y embeberlo. Esto hace al archivo 100% portable — funciona aunque el usuario lo mueva a otro lugar.

```bash
# En el container, antes de generar el HTML:
base64 -w 0 /mnt/skills/user/ukelele-html/assets/logo-ukelele-color.png
```

Luego en el HTML:
```html
<img src="data:image/png;base64,iVBORw0KG..." alt="Ukelele Growth Company" class="uke-logo" />
```

**Artifact React**: en Claude.ai los artifacts no pueden cargar archivos externos. Hay dos opciones:
1. Si no es crítico el branding visual del logo: usar el **wordmark CSS** (texto "uke." en Montserrat ExtraBold rojo) como fallback elegante.
2. Si el logo es importante: pedirle al usuario que lo suba como recurso del artifact, o usar base64 inline igual que en HTML standalone.

Ver `references/react-patterns.md` para snippets exactos.

### Reglas de uso del logo

- Sobre fondos claros → versión **color**
- Sobre fondos oscuros → versión **blanca**
- Tamaño mínimo: 80px de ancho (legibilidad del texto "UKELELE GROWTH COMPANY")
- Tamaño usual en headers/footers: 100–140px
- Tamaño en hero: 180–240px
- Posición predeterminada: esquina superior izquierda o superior derecha. En cierres: centrado.
- **No** distorsionar, rotar, recortar ni cambiar colores del logo.
- **No** ponerlo sobre imagen sin overlay si no se distingue claramente.

---

## Tipografías

En HTML/React cargar desde Google Fonts. Proxima Nova **no** está en Google Fonts; usar **Lato** como fallback para cuerpo (similar en proporciones).

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&family=Lato:wght@400;700;900&display=swap" rel="stylesheet">
```

CSS:
```css
:root {
  --uke-font-display: 'Montserrat', system-ui, -apple-system, sans-serif;
  --uke-font-body: 'Lato', 'Helvetica Neue', Arial, sans-serif;
}
```

Detalle completo de pesos y tamaños por tipo de elemento → `references/brand-spec.md`.

---

## Regla de oro

> Si dudás entre ser genérico o ser on-brand, elegí on-brand. La identidad de Ukelele tiene carácter fuerte: rojo, Montserrat, Lato, números grandes, mucho whitespace, diseño limpio con elementos visuales en cada sección. Nunca producir páginas con aspecto de "template Bootstrap default". Cada pieza web tiene que sentirse Ukelele desde el primer scroll.
